
import React from 'react';
import { Level, Region, ReverseLogisticsMode, ArticleType, BusinessBuffers } from '../types';
import { ARTICLE_SPECIFICATIONS } from '../constants';

interface CalculatorFormProps {
  articleType: ArticleType;
  setArticleType: (val: ArticleType) => void;
  tpPrice: number;
  setTpPrice: (val: number) => void;
  targetSettlement: number;
  setTargetSettlement: (val: number) => void;
  level: Level;
  setLevel: (val: Level) => void;
  isReverse: boolean;
  setIsReverse: (val: boolean) => void;
  reverseRegion: Region;
  setReverseRegion: (val: Region) => void;
  reverseMode: ReverseLogisticsMode;
  setReverseMode: (val: ReverseLogisticsMode) => void;
  reversePercent: number;
  setReversePercent: (val: number) => void;
  buffers: BusinessBuffers;
  setBuffers: (val: BusinessBuffers) => void;
}

const CalculatorForm: React.FC<CalculatorFormProps> = ({
  articleType,
  setArticleType,
  tpPrice,
  setTpPrice,
  targetSettlement,
  level,
  setLevel,
  buffers,
  setBuffers
}) => {
  const handleArticleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newType = e.target.value as ArticleType;
    setArticleType(newType);
    const spec = ARTICLE_SPECIFICATIONS[newType];
    if (spec) setLevel(spec.defaultLevel);
  };

  const updateBuffer = (key: keyof BusinessBuffers, val: number) => {
    setBuffers({ ...buffers, [key]: val });
  };

  return (
    <div className="space-y-4 bg-slate-900 p-6 border border-white/10 rounded-none shadow-2xl">
      <div className="border-b border-white/10 pb-4">
        <h2 className="text-xs font-black text-white tracking-widest uppercase">INPUT CONFIGURATION</h2>
      </div>
      
      <div className="space-y-4">
        <div className="group">
          <label className="text-[9px] font-black text-slate-500 uppercase block mb-1 tracking-tighter">Article Type</label>
          <select 
            value={articleType}
            onChange={handleArticleChange}
            className="w-full px-4 py-2.5 border border-white/10 bg-slate-950 text-white font-bold outline-none focus:border-blue-500 transition-all rounded-none text-xs appearance-none"
          >
            {Object.values(ArticleType).map(type => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
        </div>

        <div className="group">
          <label className="text-[9px] font-black text-blue-400 uppercase block mb-1 tracking-tighter">Base TP Cost (Input)</label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30 font-bold text-sm">₹</span>
            <input
              type="number"
              value={tpPrice || ''}
              onChange={(e) => setTpPrice(Number(e.target.value))}
              className="w-full pl-8 pr-4 py-3 border border-white/10 bg-slate-950 focus:border-blue-500 outline-none transition-all font-black text-xl text-white rounded-none"
              placeholder="0.00"
            />
          </div>
        </div>

        <div className="bg-slate-950 p-4 border border-white/5 space-y-4">
          <div className="flex justify-between items-center border-b border-white/5 pb-2">
            <h3 className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Markups (On TP)</h3>
            <span className="text-[8px] font-bold text-blue-400 bg-blue-600/10 px-2 py-0.5 border border-blue-600/20">ADDITIVE MULTIPLIERS</span>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {Object.keys(buffers).map((key) => (
              <div key={key} className="space-y-1">
                <label className="text-[7px] font-black text-slate-500 uppercase tracking-tight">{key.replace('Percent','').toUpperCase()}</label>
                <div className="relative">
                   <input 
                    type="number" 
                    value={(buffers as any)[key]} 
                    onChange={(e) => updateBuffer(key as keyof BusinessBuffers, Number(e.target.value))} 
                    className="w-full px-3 py-2 border border-white/5 bg-slate-900 text-[11px] font-black text-white outline-none focus:border-blue-500 rounded-none" 
                  />
                   <span className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-700 text-[8px] font-bold">%</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-blue-600/5 border-l-4 border-blue-500 p-5 rounded-none">
          <label className="text-[8px] font-black text-blue-400 uppercase block mb-2">Resulting Target Settlement</label>
          <div className="flex justify-between items-end">
            <div>
               <p className="text-[8px] font-bold text-slate-500 mb-0.5">TP + MARKUP SUM</p>
               <span className="text-3xl font-black text-white tracking-tighter leading-none">₹{targetSettlement.toLocaleString()}</span>
            </div>
            <div className="text-right">
               <span className="text-[10px] font-black text-emerald-400 leading-none">100% VERIFIED</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-5 gap-px bg-white/5 p-px">
          {Object.values(Level).map((l) => (
            <button
              key={l}
              onClick={() => setLevel(l)}
              className={`py-3 text-[9px] font-black transition-all rounded-none uppercase ${
                level === l ? 'bg-blue-600 text-white' : 'bg-slate-950 text-slate-500 hover:text-slate-200'
              }`}
            >
              {l.replace('Level ', 'L')}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CalculatorForm;
