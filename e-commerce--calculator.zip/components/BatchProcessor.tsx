
import React, { useState, useRef, useMemo } from 'react';
import * as XLSX from 'https://esm.sh/xlsx';
import { Level, Region, ArticleType, ReverseLogisticsMode, Gender, MasterCategory, BusinessBuffers } from '../types';
import { findAISPForTarget, calculateBreakdown } from '../services/calculatorService';
import { ARTICLE_SPECIFICATIONS, GST_RATE } from '../constants';

interface BatchProcessorProps {
  buffers: BusinessBuffers;
  setBuffers: (val: BusinessBuffers) => void;
}

const BatchProcessor: React.FC<BatchProcessorProps> = ({ buffers, setBuffers }) => {
  const [uploadedData, setUploadedData] = useState<any[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isBuffersEnabled, setIsBuffersEnabled] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const round = (num: number) => Math.round((num + Number.EPSILON) * 100) / 100;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const json = XLSX.utils.sheet_to_json(ws) as any[];

        const rows = json.map(row => {
          const styleIdVal = row['Style Id'] || row['Style ID'] || row['SKU'] || row['Style'];
          const genderVal = row['Gender*'] || row['Gender'] || Object.values(row)[0];
          const masterVal = row['Master Category'] || Object.values(row)[1];
          const subCategoryVal = row['Sub Category'] || row['Article Type'] || Object.values(row)[2];
          const tpVal = row['TP (Cost)*'] || row['TP Cost'] || row['TP'] || Object.values(row)[3];
          
          let parsedArticle: ArticleType | undefined;
          if (subCategoryVal) {
            parsedArticle = Object.values(ArticleType).find(v => v.toLowerCase() === String(subCategoryVal).toLowerCase());
          }

          let parsedGender: Gender | undefined;
          if (genderVal) {
            const cleanGender = String(genderVal).replace('*', '').trim().toLowerCase();
            parsedGender = Object.values(Gender).find(v => v.toLowerCase() === cleanGender);
          }

          return {
            styleId: styleIdVal ? String(styleIdVal) : 'N/A',
            tp: parseFloat(String(tpVal).replace(/[₹,]/g, '')),
            articleType: parsedArticle || ArticleType.TSHIRTS, 
            gender: parsedGender || Gender.UNISEX,
            masterCategory: masterVal || MasterCategory.APPAREL
          };
        }).filter(r => !isNaN(r.tp));

        setUploadedData(rows);
      } catch (err) {
        console.error(err);
        alert("Excel error. Check file format.");
      } finally {
        setIsProcessing(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.readAsBinaryString(file);
  };

  const results = useMemo(() => {
    // Total Buffer Sum based on TP only
    const totalBufferSum = buffers.adsPercent + buffers.dealDiscountPercent + buffers.reviewPercent + buffers.profitMarginPercent + buffers.returnPercent;
    const bufferMultiplier = isBuffersEnabled ? (totalBufferSum / 100) : 0;

    return uploadedData.map(row => {
      // Logic: Target Settlement = Base TP + (TP * buffers%)
      const markupAmount = row.tp * bufferMultiplier;
      const target = round(row.tp + markupAmount);
      
      const spec = ARTICLE_SPECIFICATIONS[row.articleType as ArticleType];
      const level = spec?.defaultLevel || Level.LEVEL_2;
      
      const aisp = findAISPForTarget(target, level, row.articleType, false, Region.LOCAL, ReverseLogisticsMode.FIXED, 0);
      const breakdown = calculateBreakdown(aisp, level, row.articleType, false, Region.LOCAL, ReverseLogisticsMode.FIXED, 0);
      
      return { 
        ...breakdown, 
        baseTp: row.tp,
        markupAmount: markupAmount,
        styleId: row.styleId,
        articleType: row.articleType,
        gender: row.gender,
        masterCategory: row.masterCategory,
        level: level,
        targetSettlement: target
      };
    });
  }, [uploadedData, buffers, isBuffersEnabled]);

  const downloadTemplate = () => {
    const headers = ['Style Id', 'Gender*', 'Master Category', 'Sub Category', 'TP (Cost)*'];
    const sampleData = [['SKU001', 'Men', 'APPAREL', 'Tshirts', 350]];
    const wsData = [headers, ...sampleData];
    const ws = XLSX.utils.aoa_to_sheet(wsData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Template");
    XLSX.writeFile(wb, "Template.xlsx");
  };

  const exportToExcel = () => {
    const headers = ['SKU', 'TP Cost', 'Markup', 'Target Settlement', 'AISP', 'Bank Recieved', 'Profit', 'ROI%'];
    const wsData: any[][] = [headers];
    results.forEach(item => {
      const profit = item.totalActualSettlement - (item.baseTp || 0);
      const roi = (item.baseTp && item.baseTp > 0) ? (profit / item.baseTp) * 100 : 0;
      wsData.push([item.styleId, round(item.baseTp || 0), round(item.markupAmount || 0), round(item.targetSettlement || 0), round(item.aisp), round(item.totalActualSettlement), round(profit), round(roi)]);
    });
    const ws = XLSX.utils.aoa_to_sheet(wsData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Export");
    XLSX.writeFile(wb, `Pricing_Architect_Batch.xlsx`);
  };

  return (
    <div className="w-full mx-auto px-4">
      {/* Compact Sharp Control Panel */}
      <div className="bg-slate-900 border border-white/10 mb-6 flex flex-col lg:flex-row gap-4 items-center p-4 rounded-none shadow-xl">
        
        {/* File Section */}
        <div className="lg:w-1/5 w-full">
          <div onClick={() => fileInputRef.current?.click()} className="cursor-pointer border border-white/10 bg-slate-950 hover:bg-slate-800 p-3 flex items-center gap-3 h-[50px] rounded-none border-dashed transition-all">
            <input type="file" onChange={handleFileUpload} className="hidden" ref={fileInputRef} accept=".xlsx, .xls, .csv" />
            <div className="w-8 h-8 bg-blue-600 flex items-center justify-center rounded-none text-white">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/></svg>
            </div>
            <div className="flex flex-col">
              <span className="text-white font-black text-[10px] uppercase tracking-tighter leading-none">Catalog Upload</span>
              <button onClick={(e) => { e.stopPropagation(); downloadTemplate(); }} className="text-[7px] font-bold text-blue-400 uppercase tracking-tighter opacity-70 hover:opacity-100">Get Template</button>
            </div>
          </div>
        </div>

        {/* Buffers with Explicit Enable/Disable */}
        <div className="lg:w-3/5 w-full flex items-center gap-4 bg-slate-950/50 p-2 border border-white/5 rounded-none">
          <div className="flex flex-col items-center justify-center px-4 border-r border-white/5">
             <label className="text-[7px] font-black text-slate-500 uppercase mb-1">Buffers</label>
             <button 
                onClick={() => setIsBuffersEnabled(!isBuffersEnabled)}
                className={`w-12 h-6 rounded-none relative transition-all ${isBuffersEnabled ? 'bg-emerald-600' : 'bg-slate-800'}`}
             >
                <div className={`absolute top-0.5 w-5 h-5 bg-white transition-all ${isBuffersEnabled ? 'right-0.5' : 'left-0.5'}`}></div>
                <span className="absolute inset-0 flex items-center justify-center text-[6px] font-black text-white uppercase pointer-events-none">
                  {isBuffersEnabled ? 'ON' : 'OFF'}
                </span>
             </button>
          </div>

          <div className={`grid grid-cols-5 gap-3 flex-1 transition-all ${isBuffersEnabled ? 'opacity-100' : 'opacity-20 pointer-events-none'}`}>
            {Object.keys(buffers).map((key) => (
              <div key={key} className="relative group">
                <label className="text-[7px] font-black text-slate-500 uppercase tracking-tighter block mb-0.5">{key.replace('Percent','')}</label>
                <div className="relative">
                  <input 
                    type="number" 
                    value={(buffers as any)[key]} 
                    onChange={(e) => setBuffers({...buffers, [key]: Number(e.target.value)})} 
                    className="w-full px-2 py-1.5 bg-slate-950 border border-white/10 text-white font-black outline-none focus:border-blue-500 text-[10px] rounded-none" 
                  />
                  <span className="absolute right-1 top-1/2 -translate-y-1/2 text-slate-600 font-bold text-[7px]">%</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Action Button */}
        <div className="lg:w-1/5 w-full">
          {results.length > 0 && (
            <button onClick={exportToExcel} className="w-full bg-blue-600 hover:bg-blue-500 text-white p-4 font-black text-[9px] uppercase flex items-center justify-center gap-2 rounded-none transition-all shadow-lg active:scale-95">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
              Generate Excel
            </button>
          )}
        </div>
      </div>

      {/* Results Table - Sharp, Industrial, Data Dense */}
      {results.length > 0 && (
        <div className="bg-slate-900 border border-white/10 overflow-hidden mb-12 rounded-none shadow-2xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[1600px] table-fixed">
              <thead className="bg-slate-950 border-b border-white/10">
                <tr className="divide-x divide-white/5">
                  <th className="w-40 px-4 py-3 text-[8px] font-black text-slate-500 uppercase">Style SKU</th>
                  <th className="w-48 px-4 py-3 text-[8px] font-black text-slate-500 uppercase">Article Type</th>
                  <th className="w-24 px-4 py-3 text-[8px] font-black text-slate-500 uppercase text-center">G / L</th>
                  <th className="w-32 px-4 py-3 text-[8px] font-black text-blue-400 uppercase text-right">TP Cost</th>
                  <th className="w-40 px-4 py-3 text-[8px] font-black text-indigo-400 uppercase text-right">Target (TP+Markup)</th>
                  <th className="w-32 px-4 py-3 text-[8px] font-black text-rose-400 uppercase text-right">Comm ({results[0].commissionRate}%)</th>
                  <th className="w-32 px-4 py-3 text-[8px] font-black text-rose-400 uppercase text-right">Fees+GST</th>
                  <th className="w-48 px-4 py-3 text-[8px] font-black text-white uppercase text-right bg-blue-600/20">AISP (Selling)</th>
                  <th className="w-48 px-4 py-3 text-[8px] font-black text-emerald-400 uppercase text-right bg-emerald-600/10">Settlement</th>
                  <th className="w-32 px-4 py-3 text-[8px] font-black text-white uppercase text-right">Profit</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {results.map((row, idx) => {
                  const fees = (row.fixedFee + row.reverseLogisticsFee) * (1 + GST_RATE) + row.tcs + row.tds;
                  const profit = row.totalActualSettlement - (row.baseTp || 0);
                  const roi = (row.baseTp && row.baseTp > 0) ? (profit / row.baseTp) * 100 : 0;
                  return (
                    <tr key={idx} className="hover:bg-white/[0.02] transition-colors divide-x divide-white/5">
                      <td className="px-4 py-2">
                        <span className="text-[9px] font-bold text-blue-400 border border-blue-500/20 px-2 py-0.5 inline-block">{row.styleId}</span>
                      </td>
                      <td className="px-4 py-2">
                        <span className="font-black text-white text-xs block truncate">{row.articleType}</span>
                        <span className="text-[6px] text-slate-500 font-bold uppercase">{row.masterCategory}</span>
                      </td>
                      <td className="px-4 py-2 text-center">
                        <div className="flex flex-col gap-0.5">
                          <span className="text-[7px] font-bold text-slate-400 uppercase">{row.gender}</span>
                          <span className="text-[7px] font-bold text-indigo-400 uppercase">{row.level.replace('Level ','L')}</span>
                        </div>
                      </td>
                      <td className="px-4 py-2 text-right font-bold text-slate-400 text-xs">₹{round(row.baseTp || 0).toLocaleString()}</td>
                      <td className="px-4 py-2 text-right">
                        <div className="flex flex-col items-end">
                           <span className="font-black text-indigo-400 text-xs">₹{row.targetSettlement?.toLocaleString()}</span>
                           <span className="text-[6px] text-slate-600">Markup: ₹{round(row.markupAmount || 0)}</span>
                        </div>
                      </td>
                      <td className="px-4 py-2 text-right font-bold text-rose-500/80 text-xs">₹{round(row.commission).toLocaleString()}</td>
                      <td className="px-4 py-2 text-right font-bold text-rose-500/80 text-xs">₹{round(fees).toLocaleString()}</td>
                      <td className="px-4 py-2 text-right bg-blue-600/[0.05]">
                        <span className="font-black text-white text-xl tracking-tighter">₹{round(row.aisp).toLocaleString()}</span>
                      </td>
                      <td className="px-4 py-2 text-right bg-emerald-600/[0.05]">
                        <span className="font-black text-emerald-400 text-lg">₹{round(row.totalActualSettlement).toLocaleString()}</span>
                      </td>
                      <td className="px-4 py-2 text-right">
                        <div className="flex flex-col items-end">
                          <span className={`font-black text-xs ${profit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {profit >= 0 ? '+' : ''}₹{round(profit).toLocaleString()}
                          </span>
                          <span className={`text-[7px] font-bold ${roi >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                            {round(roi)}% ROI
                          </span>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default BatchProcessor;
