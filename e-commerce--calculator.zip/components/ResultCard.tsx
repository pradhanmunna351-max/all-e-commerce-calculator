
import React from 'react';
import { PricingResult, ReverseLogisticsMode } from '../types';
import { GST_RATE } from '../constants';

interface ResultCardProps {
  result: PricingResult;
  baseTp: number;
  targetSettlement: number;
}

const ResultCard: React.FC<ResultCardProps> = ({ result, baseTp, targetSettlement }) => {
  const format = (val: number, decimals: number = 2) => 
    `₹${val.toLocaleString('en-IN', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}`;

  const marketplaceCosts = result.commission + (result.fixedFee * (1 + GST_RATE)) + (result.reverseLogisticsFee * (1 + GST_RATE)) + result.tcs + result.tds;
  const growthAdded = targetSettlement - baseTp;

  return (
    <div className="flex flex-col gap-6">
      <div className="bg-slate-900 p-10 border border-white/10 shadow-2xl relative rounded-none flex flex-col items-center justify-center overflow-hidden">
        <div className="absolute top-0 left-0 w-2 h-full bg-blue-600"></div>
        <div className="relative z-10 text-center space-y-3">
          <p className="text-blue-500 text-[11px] font-black uppercase tracking-[0.4em]">Required AISP (Selling Price)</p>
          <h3 className="text-7xl font-black tracking-tighter text-white leading-none">
            {format(result.aisp)}
          </h3>
          <div className="flex justify-center gap-4 pt-6">
            <div className="px-6 py-2 bg-slate-950 text-white text-[10px] font-black border border-white/10 rounded-none flex flex-col items-center">
              <span className="opacity-40 mb-1">CUSTOMER PRICE</span>
              <span>{format(result.customerPrice)}</span>
            </div>
            <div className="px-6 py-2 bg-slate-950 text-slate-400 text-[10px] font-black border border-white/10 rounded-none flex flex-col items-center">
              <span className="opacity-40 mb-1">GTA LOGISTICS</span>
              <span>{format(result.logisticsFee)}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-slate-950 p-8 border border-white/10 shadow-2xl space-y-8 rounded-none relative">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          <div className="space-y-4">
            <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest border-b border-white/10 pb-2">Cost Breakdown</h4>
            <div className="space-y-3">
              <div className="flex justify-between items-center"><span className="text-[10px] text-slate-400 uppercase">Comm ({result.commissionRate}%)</span><span className="font-bold text-rose-500 text-sm">-{format(result.commission)}</span></div>
              <div className="flex justify-between items-center"><span className="text-[10px] text-slate-400 uppercase">Fees (Inc. GST)</span><span className="font-bold text-rose-500 text-sm">-{format(marketplaceCosts - result.commission)}</span></div>
              <div className="flex justify-between items-center pt-3 border-t border-white/10"><span className="text-[10px] font-black text-slate-400 uppercase">Deduction Sum</span><span className="font-black text-rose-600 text-base">-{format(marketplaceCosts)}</span></div>
            </div>
          </div>
          <div className="space-y-4">
            <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest border-b border-white/10 pb-2">Calculated Target</h4>
            <div className="space-y-3">
              <div className="flex justify-between items-center"><span className="text-[10px] text-slate-400 uppercase">Base TP Cost</span><span className="font-bold text-white text-sm">{format(baseTp)}</span></div>
              <div className="flex justify-between items-center"><span className="text-[10px] text-slate-400 uppercase">Markup Added</span><span className="font-bold text-blue-400 text-sm">+{format(growthAdded)}</span></div>
              <div className="flex justify-between items-center pt-3 border-t border-white/10"><span className="text-[10px] font-black text-slate-400 uppercase">Net Target</span><span className="font-black text-indigo-400 text-base">{format(targetSettlement)}</span></div>
            </div>
          </div>
        </div>

        <div className="bg-emerald-600/5 border border-emerald-500/20 p-6 flex justify-between items-center rounded-none relative">
          <div className="absolute left-0 top-0 h-full w-1 bg-emerald-500"></div>
          <div className="flex flex-col">
            <span className="text-[10px] font-black text-emerald-400 uppercase mb-2 tracking-widest">Final Verified Bank Deposit</span>
            <span className="text-4xl font-black text-white tracking-tighter">
              {format(result.totalActualSettlement)}
            </span>
          </div>
          <div className="flex flex-col items-end gap-2">
            <div className="w-12 h-12 bg-emerald-600 text-white flex items-center justify-center rounded-none shadow-lg">
               <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            </div>
            <span className="text-[8px] font-bold text-slate-500 uppercase">Verified Secure</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResultCard;
