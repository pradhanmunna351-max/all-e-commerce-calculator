
import React, { useState, useMemo, useEffect } from 'react';
import { Level, Region, ArticleType, ReverseLogisticsMode, BusinessBuffers } from './types';
import { findAISPForTarget, calculateBreakdown } from './services/calculatorService';
import CalculatorForm from './components/CalculatorForm';
import ResultCard from './components/ResultCard';
import BatchProcessor from './components/BatchProcessor';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'single' | 'batch'>('single');
  
  const [tpPrice, setTpPrice] = useState<number>(300);
  const [targetSettlement, setTargetSettlement] = useState<number>(397.83);
  const [articleType, setArticleType] = useState<ArticleType>(ArticleType.TSHIRTS);
  const [level, setLevel] = useState<Level>(Level.LEVEL_2);
  const [isReverse, setIsReverse] = useState<boolean>(false);
  const [reverseRegion, setReverseRegion] = useState<Region>(Region.LOCAL);
  const [reverseMode, setReverseMode] = useState<ReverseLogisticsMode>(ReverseLogisticsMode.FIXED);
  const [reversePercent, setReversePercent] = useState<number>(10);
  
  const [buffers, setBuffers] = useState<BusinessBuffers>({
    adsPercent: 5,
    dealDiscountPercent: 10,
    reviewPercent: 2,
    profitMarginPercent: 15,
    returnPercent: 5
  });

  useEffect(() => {
    // Logic: Markup on Cost ONLY. (TP * (Ads% + Deal% + ...))
    const totalBufferSum = buffers.adsPercent + buffers.dealDiscountPercent + buffers.reviewPercent + buffers.profitMarginPercent + buffers.returnPercent;
    const markupAmount = tpPrice * (totalBufferSum / 100);
    const newTarget = tpPrice + markupAmount;
    setTargetSettlement(parseFloat(newTarget.toFixed(2)));
  }, [tpPrice, buffers]);

  const result = useMemo(() => {
    const aisp = findAISPForTarget(targetSettlement, level, articleType, isReverse, reverseRegion, reverseMode, reversePercent);
    return calculateBreakdown(aisp, level, articleType, isReverse, reverseRegion, reverseMode, reversePercent);
  }, [targetSettlement, level, articleType, isReverse, reverseRegion, reverseMode, reversePercent]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 overflow-x-hidden relative font-mono">
      {/* Sharp Accent Lines */}
      <div className="fixed inset-0 pointer-events-none opacity-10">
        <div className="absolute top-0 left-0 w-full h-px bg-blue-500"></div>
        <div className="absolute bottom-0 left-0 w-full h-px bg-blue-500"></div>
      </div>

      <div className="relative z-10 w-full max-w-[1920px] mx-auto py-6 px-4">
        <header className="mb-6 flex items-center justify-between border border-white/10 bg-slate-900 p-4 rounded-none shadow-xl">
          <div className="flex items-center gap-6">
            <div className="w-10 h-10 bg-blue-600 text-white flex items-center justify-center rounded-none font-black text-xl">P</div>
            <div>
              <h1 className="text-xl font-black text-white tracking-tighter uppercase leading-none">PRICING ARCHITECT</h1>
              <p className="text-[8px] text-slate-500 font-bold tracking-[0.3em] uppercase mt-1">Settlement Optimization Engine</p>
            </div>
          </div>
          
          <div className="bg-slate-950 p-1 flex border border-white/5">
            <button 
              onClick={() => setActiveTab('single')} 
              className={`px-8 py-2 text-[10px] font-black uppercase transition-all ${activeTab === 'single' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:text-slate-200'}`}
            >
              Single Tool
            </button>
            <button 
              onClick={() => setActiveTab('batch')} 
              className={`px-8 py-2 text-[10px] font-black uppercase transition-all ${activeTab === 'batch' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:text-slate-200'}`}
            >
              Batch Engine
            </button>
          </div>
        </header>

        <main className="transition-all duration-300">
          {activeTab === 'single' ? (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start max-w-[1500px] mx-auto">
              <div className="lg:col-span-5 order-2 lg:order-1">
                <CalculatorForm 
                  articleType={articleType} 
                  setArticleType={setArticleType} 
                  tpPrice={tpPrice} 
                  setTpPrice={setTpPrice} 
                  targetSettlement={targetSettlement} 
                  setTargetSettlement={setTargetSettlement} 
                  level={level} 
                  setLevel={setLevel} 
                  isReverse={isReverse} 
                  setIsReverse={setIsReverse} 
                  reverseRegion={reverseRegion} 
                  setReverseRegion={setReverseRegion} 
                  reverseMode={reverseMode} 
                  setReverseMode={setReverseMode} 
                  reversePercent={reversePercent} 
                  setReversePercent={setReversePercent} 
                  buffers={buffers} 
                  setBuffers={setBuffers} 
                />
              </div>
              <div className="lg:col-span-7 order-1 lg:order-2">
                <div className="sticky top-6">
                  <ResultCard result={result} baseTp={tpPrice} targetSettlement={targetSettlement} />
                </div>
              </div>
            </div>
          ) : (
            <BatchProcessor buffers={buffers} setBuffers={setBuffers} />
          )}
        </main>
      </div>
    </div>
  );
};

export default App;
